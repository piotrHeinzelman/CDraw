#include "mlist.h"

MList::MList(){

}
