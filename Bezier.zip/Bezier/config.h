#ifndef CONFIG_H
#define CONFIG_H

#include <QString>


class Config {
public:
    const static int WIDTH=599;
    const static int HEIGHT=559;
    const static int MOUSE_OFFSET_X=0;
    const static int MOUSE_OFFSET_Y=0;


    Config();

};

#endif // CONFIG_H
