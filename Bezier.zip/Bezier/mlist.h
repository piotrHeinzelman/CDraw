#ifndef MLIST_H
#define MLIST_H

#include <QListView>

class MList : public QListView
{
    Q_OBJECT
public:
    MList();
};

#endif // MLIST_H
