#include "mitem.h"

MItem::MItem( MSegment* link, QString label ){};
